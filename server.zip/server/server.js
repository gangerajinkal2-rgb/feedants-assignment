const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const competitionRoutes = require('./routes/competitionRoutes');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI;

// Mount Routes
app.use('/api/competitions', competitionRoutes);

// MongoDB Connection
mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB Atlas successfully! ✅');
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT} 🚀`);
    });
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });