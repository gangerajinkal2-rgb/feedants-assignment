const express = require('express');
const router = express.Router();
const Competition = require('../models/Competition');

// 1. Get Competition Details by ID
router.get('/:id', async (req, res) => {
  try {
    const competition = await Competition.findById(req.params.id);
    if (!competition) {
      return res.status(404).json({ message: 'Competition not found' });
    }
    res.status(200).json(competition);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// 2. Register for Competition (With Concurrency & Spot Handling)
router.post('/:id/register', async (req, res) => {
  try {
    const { userId } = req.body;
    const competitionId = req.params.id;

    // Atomic update to handle concurrent registrations safely
    const competition = await Competition.findOneAndUpdate(
      { 
        _id: competitionId, 
        availableSpots: { $gt: 0 }, 
        status: 'active',
        registeredUsers: { $ne: userId } // Prevent duplicate registration
      },
      { 
        $inc: { availableSpots: -1 },
        $push: { registeredUsers: userId }
      },
      { new: true }
    );

    if (!competition) {
      return res.status(400).json({ 
        message: 'Registration failed. Either competition is closed, full, you are already registered, or no spots left.' 
      });
    }

    res.status(200).json({ 
      message: 'Successfully registered for the competition! 🎉', 
      competition 
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;