import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator, 
  Alert 
} from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

const COMPETITION_ID = '6ab25421d5d32d6704ea28aa'; // આપણો MongoDB નો ડમી ID
const USER_ID = '65f1a2b3c4d5e6f7a8b9c0d1'; // ડમી યૂઝર ID

export default function CompetitionDetailScreen() {
  const [competition, setCompetition] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isRegistered, setIsRegistered] = useState(false);

  // Fetch Competition Details from Backend API
  useEffect(() => {
    fetchCompetitionDetails();
  }, []);

  const fetchCompetitionDetails = async () => {
    try {
      const response = await fetch(`http://10.0.2.2:5000/api/competitions/${COMPETITION_ID}`);
      const data = await response.json();
      if (response.ok) {
        setCompetition(data);
      } else {
        Alert.alert('Error', data.message || 'Failed to load details');
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Error', 'Network error while fetching details');
    } finally {
      setLoading(false);
    }
  };

  // Handle Registration Action
  const handleRegister = async () => {
    try {
      const response = await fetch(`http://10.0.2.2:5000/api/competitions/${COMPETITION_ID}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: USER_ID })
      });
      const data = await response.json();

      if (response.ok) {
        setIsRegistered(true);
        setCompetition(data.competition);
        Alert.alert('Success', data.message);
      } else {
        Alert.alert('Notice', data.message);
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Error', 'Registration failed');
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#00796B" />
      </View>
    );
  }

  if (!competition) {
    return (
      <View style={styles.center}>
        <Text>Competition not found.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>{competition.title}</Text>
        {isRegistered && (
          <View style={styles.registeredBadge}>
            <Ionicons name="checkmark-circle" size={16} color="#00796B" />
            <Text style={styles.registeredText}>Registered</Text>
          </View>
        )}
      </View>

      {/* Tags */}
      <View style={styles.tagRow}>
        <View style={styles.tag}><Text style={styles.tagText}>Dance</Text></View>
        <View style={styles.tag}><Text style={styles.tagText}>Multi-Win</Text></View>
        <View style={styles.tag}><Text style={styles.tagText}>Winners get certificate</Text></View>
      </View>

      {/* Price Pool & Entry Fee & Spots */}
      <View style={styles.statsCard}>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Prize Pool</Text>
          <Text style={styles.statValue}>{competition.prizePool}</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Entry Fee</Text>
          <Text style={styles.statValue}>₹{competition.entryFee}</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Spots Left</Text>
          <Text style={styles.statValueSpot}>{competition.availableSpots} left</Text>
        </View>
      </View>

      {/* Judge Section */}
      <View style={styles.judgeCard}>
        <View>
          <Text style={styles.judgeTitle}>Judge</Text>
          <Text style={styles.judgeName}>Manju Dubey</Text>
          <Text style={styles.judgeSub}>Professional Kathak Dancer</Text>
        </View>
        <TouchableOpacity style={styles.videoBtn}>
          <Ionicons name="play" size={20} color="#00796B" />
          <Text style={styles.videoText}>Intro Video</Text>
        </TouchableOpacity>
      </View>

      {/* Registration Status / Action Button */}
      <View style={styles.bottomBar}>
        <TouchableOpacity 
          style={[styles.actionButton, isRegistered && styles.disabledButton]} 
          onPress={handleRegister}
          disabled={isRegistered}
        >
          <Text style={styles.actionButtonText}>
            {isRegistered ? 'Upload Submission (Registered)' : 'Register Now'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA' },
  contentContainer: { padding: 16, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  title: { fontSize: 22, fontWeight: 'bold', color: '#111', flex: 1 },
  registeredBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E0F2F1', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  registeredText: { color: '#00796B', fontWeight: 'bold', marginLeft: 4, fontSize: 12 },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 15 },
  tag: { backgroundColor: '#EFEFEF', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, marginRight: 8, marginBottom: 5 },
  tagText: { fontSize: 12, color: '#555' },
  statsCard: { flexDirection: 'row', backgroundColor: '#FFF', borderRadius: 12, padding: 15, justifyContent: 'space-between', alignItems: 'center', marginBottom: 15, elevation: 2 },
  statItem: { alignItems: 'center', flex: 1 },
  statLabel: { fontSize: 12, color: '#777' },
  statValue: { fontSize: 16, fontWeight: 'bold', color: '#00796B', marginTop: 4 },
  statValueSpot: { fontSize: 15, fontWeight: 'bold', color: '#D32F2F', marginTop: 4 },
  statDivider: { width: 1, height: '80%', backgroundColor: '#EEE' },
  judgeCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 15, elevation: 2 },
  judgeTitle: { fontSize: 11, color: '#888', textTransform: 'uppercase' },
  judgeName: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  judgeSub: { fontSize: 12, color: '#555' },
  videoBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E0F2F1', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  videoText: { color: '#00796B', fontWeight: 'bold', marginLeft: 4, fontSize: 12 },
  bottomBar: { marginTop: 20 },
  actionButton: { backgroundColor: '#00796B', padding: 16, borderRadius: 12, alignItems: 'center' },
  disabledButton: { backgroundColor: '#558B6E' },
  actionButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' }
});