const mongoose = require('mongoose');

const competitionSchema = new mongoose.Schema({
  title: { type: String, required: true },
  prizePool: { type: String, required: true },
  entryFee: { type: Number, required: true },
  totalSpots: { type: Number, required: true },
  availableSpots: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['active', 'closed', 'ended'], 
    default: 'active' 
  },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  registeredUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  winners: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true });

module.exports = mongoose.model('Competition', competitionSchema);